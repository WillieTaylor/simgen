extern int BraceLevel;

void InitializeStack(void);
void PushLevels(void);
int  PopLevels(void);
void CleanStack(void);
void PushBrace(void);
int  PopBrace(void);
void myprintStack(void);
