int TryVariableIgnore(const char *command);
void Ignore_Environment(char *endstring);
int TryPackageIgnore(const char *package);
