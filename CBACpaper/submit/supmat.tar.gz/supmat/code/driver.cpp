#include "util.hpp"
#include "geom.hpp"
#include "cell.hpp"
#include "data.hpp"

void driver ()
{
Cell	*world = Cell::world;
Data	*model = Data::model+world->model;
}
